# AJAX_Advanced-Forum-Stats
Ajax forum stats table on index forum page

Join me to developing this extension

working on: phpBB 3.2


![alt text](http://www.php-bb.ir/pic/uploads/152857133608781.jpg)